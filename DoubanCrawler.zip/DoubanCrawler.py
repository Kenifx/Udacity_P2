# -*- coding: utf-8 -*-
import bs4
import expanddouban
import codecs
import csv
import urllib

#@ kenif@163.com

'''首先先定义一些后面要用到的list
根据审阅建议，此处最好查询网页tag来获取地区。因为手动输入容易造成错误，也不方便后期维护'''
# regions list
#locations = ['中国','大陆','美国','香港','台湾','日本','韩国','英国','法国','德国','意大利','西班牙','印度','泰国','俄罗斯','伊朗','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦']

#这里构建函数用来获取地区
locations = []

def getLocations():
    url = 'https://movie.douban.com/tag/#/?sort=S&range=9,10&tags=电影'
    html = expanddouban.getHtml(url, loadmore=False, waittime=2)
    soup = bs4.BeautifulSoup(html,"html.parser")

    content = soup.find(class_='tags').find(class_='category').next_sibling.next_sibling
    for sibling in content:
         location = sibling.find(class_='tag').get_text()
         if location != '全部地区':
             locations.append(location)

#使用函数获得地区
getLocations()


# my favorite
myFavCategory = ['战争','犯罪','科幻']


'''TASK 1 获得每个地区，类型页面的url'''
"""
return a string corresponding to the URL of douban movie lists given category and location.
https://movie.douban.com/tag/#/?sort=S&range=9,10&tags=电影
"""
def getMovieUrl(category, location):
    url = None
    base_url = "https://movie.douban.com/tag/"
    tag = "," + category + ',' +  location
    url = urllib.parse.urljoin(base_url,'#/?sort=S&range=9,10&tags=电影' + tag )
    return url

#print(getMovieUrl("剧情","美国"))

'''TASK 2

with codecs.open('html.txt','w','utf-8') as f:
    html = expanddouban.getHtml(getMovieUrl("剧情", "美国"))
    f.write(html)
'''

#html = expanddouban.getHtml(getMovieUrl("剧情","美国"))

'''TASK 3 任务3: 定义电影类'''
class Movie:
    def __init__(self, name, rate, location, category, info_link, cover_link):
        self.name = name
        self.rate = rate
        self.location = location
        self.category = category
        self.info_link = info_link
        self.cover_link = cover_link

'''TASK 4 获取豆瓣电影的信息'''
"""
return a list of Movie objects with the given category and location.
"""
def getMovies(category, location):
    html = expanddouban.getHtml(getMovieUrl(category, location))
    soup = bs4.BeautifulSoup(html,"html.parser") #bs来解析拿到的html内容

    movies = soup.find(class_='list-wp')

    names = []
    rates = []
    info_links = []
    cover_links = []

    #开始查找
    for movie in movies.find_all('a'):
        names.append(movie.find(class_="title").string)
        rates.append(movie.find(class_="rate").string)
        info_links.append(movie.get("href"))
        cover_links.append(movie.find("img").get("src"))

    #存储查找到的电影
    movie_list = []
    for i in range(len(names)):
        movie_list.append(Movie(names[i],rates[i],location,category,info_links[i],cover_links[i]))
    return movie_list
    #电影存储完毕

#getMovies函数完成


'''TASK 5 构造电影信息数据表'''
#用getMovies函数查找输出爬到的电影数据表
movies = []
for category in myFavCategory:
    for location in locations:
        movies += getMovies(category, location)

#此前一直遇到gbk编码错误，所以在网上查找方法并询问其他人的建议，于是用codecs模组解决
with open('movies.csv','w') as f:
    line = csv.writer(f)
    for movie in movies:
        line.writerow([movie.name, movie.rate, movie.location, movie.category, movie.info_link, movie.cover_link])


'''TASK6 统计电影数据
统计你所选取的每个电影类别中，数量排名前三的地区有哪些，分别占此类别电影总数的百分比为多少？'''

#统计每个类别的电影个数
#统计每个类别每个地区的电影个数

#先按category，统计每个category里的电影总数（用电影名字）
#战争
war_movie = []
#科幻science fiction
sf_movie = []
#犯罪
criminal_movie = []

for movie in movies:
    for i in range(len(myFavCategory)):
        if movie.category == '战争':
            war_movie.append(movie)
        elif movie.category == '科幻':
            sf_movie.append(movie)
        elif movie.category == '犯罪':
            criminal_movie.append(movie)

#创建dict给每个分类，然后对应国家和电影数量
war_dict = {}
sf_dict = {}
criminal_dict = {}

def countByLocation(war_movies,sf_movies,criminal_movies):
    for movie in war_movies:
        if movie.location not in war_dict:
            war_dict[movie.location] = 1
        else:
            war_dict[movie.location] += 1

    for movie in sf_movies:
        if movie.location not in sf_dict:
            sf_dict[movie.location] = 1
        else:
            sf_dict[movie.location] += 1

    for movie in criminal_movies:
        if movie.location not in criminal_dict:
            criminal_dict[movie.location] =1
        else:
            criminal_dict[movie.location] += 1

    return war_dict,sf_dict,criminal_dict

countByLocation(war_movie,sf_movie,criminal_movie)

#sort来找出每个分类, 后来最后一步用到里面top 3
war_dict_sorted = sorted(war_dict.items(), key=lambda x: x[1], reverse=True)
sf_dict_sorted = sorted(sf_dict.items(), key=lambda x: x[1], reverse=True)
criminal_dict_sorted = sorted(criminal_dict.items(), key=lambda x: x[1], reverse=True)

#根据审阅建议，此处将输出构建成函数
def output(category,sortedList,OriginalList):
    return "在{}电影中，前三的国家分别是第一：{},占比 {:.2%}, 第二：{},占比 {:.2%}，第三：{},占比 {:.2%} \n".format(
        category,
        sortedList[0][0],round(sortedList[0][1]/sum(OriginalList.values()),4),
        sortedList[1][0],round(sortedList[1][1]/sum(OriginalList.values()),4),
        sortedList[2][0],round(sortedList[2][1]/sum(OriginalList.values()),4)
         )


with open("output.txt", "w", encoding='utf-8') as f:
         f.write(output("战争",war_dict_sorted,war_dict))

         f.write(output("科幻",sf_dict_sorted, sf_dict))

         f.write(output("犯罪",criminal_dict_sorted, criminal_dict))


